// Simple form handler
document.getElementById("contactForm").addEventListener("submit", function(e) {
  e.preventDefault();
  let name = document.getElementById("name").value;
  let email = document.getElementById("email").value;
  alert("Thank you, " + name + "! We will contact you at " + email);
});